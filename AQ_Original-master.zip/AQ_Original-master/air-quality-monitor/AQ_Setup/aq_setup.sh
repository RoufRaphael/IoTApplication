#!/bin/bash
docker run -d -P -p 8086:8086 -p 8083:8083 -p 2003:2003 -v /home/ubuntu/AQ_Original/air-quality-monitor/volumes/influxdb/data:/var/lib/influxdb2 -v /home/ubuntu/AQ_Original/air-quality-monitor/volumes/influxdb/data:/etc/influxdb2 --name influxdb influxdb:latest
sleep 5
docker run -d -P -p 3000:3000 -v /home/ubuntu/AQ_Original/air-quality-monitor/volumes/grafana/data:/var/lib/grafana --user 0 --name grafana grafana/grafana
sleep 5s
docker run -d -P -p 1883:1883 -v /home/ubuntu/AQ_Original/air-quality-monitor/volumes/mosquitto/data:/data -v /home/ubuntu/AQ_Original/air-quality-monitor/services/mosquitto/mosquitto.conf:/mosquitto/config/mosquitto.conf --name mosquitto eclipse-mosquitto
sleep 5s
docker run -d -P -p 1880:1880 -v /home/ubuntu/AQ_Original/air-quality-monitor/volumes/nodered/data:/data --user 0 --name nodered nodered/node-red:latest
sleep 5s






