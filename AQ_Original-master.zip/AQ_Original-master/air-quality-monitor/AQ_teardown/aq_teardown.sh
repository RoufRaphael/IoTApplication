docker stop nodered 
docker rm nodered 

docker stop influxdb  
docker rm influxdb 

docker stop grafana  
docker rm grafana  

docker stop mosquitto  
docker rm mosquitto  


